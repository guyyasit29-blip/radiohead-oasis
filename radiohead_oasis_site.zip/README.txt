Radiohead × Oasis Random Song
==============================

เว็บไซต์เป็นไฟล์ static HTML เดียว: index.html

วิธีเผยแพร่ด้วย GitHub Pages:
1. สร้าง GitHub repository ชื่อ radiohead-oasis และตั้งเป็น Public
2. Upload ไฟล์ index.html ในโฟลเดอร์นี้ไปไว้ที่ root ของ repository
3. เปิด Settings > Pages
4. เลือก Deploy from a branch, Branch: main, Folder: /(root), แล้ว Save
5. รอให้ GitHub Pages เผยแพร่ จากนั้นเปิด URL ที่แสดงใน Safari

ปุ่มสุ่มทำงานในหน้าเว็บ และปุ่มฟังจะเปิดผลค้นหา YouTube ของเพลงที่เลือก
